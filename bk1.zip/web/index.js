

var data = []
var TICKINTERVAL = 86400000
let XAXISRANGE = 777600000

let chart;

var socket = io();
socket.on('newmsg', function (records) {
    try {
        let arr = JSON.parse(records);
        console.log(arr.length);
        if(chart){
            data = [...data,...arr];
        chart.updateSeries([{
            data: data
        }])
        }
    } catch (error) {

    }

})



window.onload = () => {
    const el = document.getElementById('chart');
    var options = {
        series: [{
            data: data.slice()
        }],
        chart: {
            id: 'realtime',
            height: 350,
            type: 'line',
            animations: {
                enabled: true,
                easing: 'linear',
                dynamicAnimation: {
                    speed: 1000
                }
            },
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth'
        },
        title: {
            text: 'Dynamic Updating Chart',
            align: 'left'
        },
        markers: {
            size: 0
        },
        xaxis: {
            type: 'datetime',
            range: undefined,
        },
        yaxis: {
            max: 100
        },
        legend: {
            show: false
        },
    };

    chart = new ApexCharts(el, options);
    chart.render();

}


